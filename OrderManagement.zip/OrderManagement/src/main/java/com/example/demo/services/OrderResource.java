package com.example.demo.services;

import com.example.demo.model.Order;

public class OrderResource {
	private Order order;
}
